<?php

$server = "REQUEST FROM: " .get_ip(). "<br>";
$get = "GET:" . json_encode($_GET) . "<br>";
$post = "POST:" . json_encode($_POST) . "<br>";
$input = "INPUT:" . file_get_contents('php://input') . "<br>";

writeInFile($server . $get . $post . $input);

function writeInFile($content) {
    date_default_timezone_set('Asia/Kolkata');
    $date = date("Y-m-d H:i:s");

    $fname = "logs" . date("Y-m-d") . ".html";
    if(!file_exists($fname)){
        $handle = fopen($fname, "w");
        fclose($handle);
    }
    $content = file_get_contents($fname) . '<hr><b>' . $date . '</b><br>' . $content;
    file_put_contents($fname, $content);
}

function get_ip() {
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    if (isset($_SERVER["REMOTE_ADDR"])) {
        return $_SERVER['REMOTE_ADDR'];
    }
}
